function task1(input, text)
{
	var count = 0;
	
	for( var i = 0; i < text.length; i++ )
	{
		if( input === text[i] )
		{
			count++;
		}
	}
	return count;
}








function task2(text)
{
	var text2 = "";
	var check = true;
	var i = 0;
	
	text = text.toLowerCase().replace(/[^a-z]+/g, "");
	
	for( i = text.length-1; i >= 0; i-- )
	{
		text2 = text2 + text[i];
	}
	
	
	for( i = 0; i < text.length; i++ )
	{
		if( !(text2[i] === text[i]) )
		{
			check = false;
			break;
		}
	}
	return check;
}







function task3a(text, wordList)
{
	var wordCount = [];
	text = text.split(" ");
	var i = 0;
	
	for( i = 0; i < wordList.length; i++ )
	{
		wordCount.push(0);
	}
	
	
	for( var j = 0; j < wordList.length; j++ )
	{
		for( i = 0; i < text.length; i++ )
		{
			if( text[i].toLowerCase().includes( wordList[j].toLowerCase() ) )
			{
				wordCount[j]++;
			}
		}
	}
	
	/*
	for( i = 0; i < wordList.length; i++ )
	{
		document.getElementById("result").innerHTML += wordList[i] + ": " + wordCount[i];
		document.getElementById("result").innerHTML += "<br>";
	}
	*/
	
	return wordCount;
}



function task3b(text, wordList)
{
	var j, i, p, q = 0;
	var newWord = "";

	//var text = "I have a cat named Meow and a dog name Woof. I love the dog a lot. He is larger than a small horse.";
	//var wordList = ["meow", "woof"];
	text = text.split(" ");
	
	
	for( j = 0; j < wordList.length; j++ )
	{
		for( i = 0; i < text.length; i++ )
		{
			if( text[i].toLowerCase().includes( wordList[j].toLowerCase() ) )
			{
				censor(text[i], wordList[j]);
				
				text[i] = text[i].toLowerCase().replace(wordList[j].toLowerCase(), newWord);
			}
		}
	}
	
	text = text.join(" ");
	//document.getElementById("result").innerHTML += text;
	return text;
	

	function censor(textWord, wordListWord)
	{
		newWord = "";
		
		for( p = 0; p < wordListWord.length; p++ )
		{
			for( q = 0; q < textWord.length; q++ )
			{
				if( wordListWord[p].toLowerCase() === textWord[q].toLowerCase() )
				{
					if( p == 0 )
					{
						newWord = newWord + textWord[q];
						break;
					}
					if( p == wordListWord.length-1 && q != 0 )
					{
						newWord = newWord + textWord[q];
						break;
					}
					else if( p != wordListWord.length-1 )
					{
						newWord = newWord + "$$";
						break;
					}
				}
			}
		}
	}
}








function task3c(text)
{
	var j, i, p, q = 0;
	var newWord = "";
	
	//var text = "Anna went to vote in the election to fulfil her civic duty";
	var wordList = [];
	text = text.split(" ");
	
	
	for( i = 0; i < text.length; i++ )
	{
		if( checkPalindrome(text[i]) )
		{
			wordList.push( text[i].toLowerCase().replace(/[^a-z]+/g, "") );
		}
	}
	
	
	for( j = 0; j < wordList.length; j++ )
	{
		for( i = 0; i < text.length; i++ )
		{
			if( text[i].toLowerCase().includes( wordList[j].toLowerCase() ) )
			{
				censor(text[i], wordList[j]);
				
				text[i] = text[i].toLowerCase().replace(wordList[j].toLowerCase(), newWord);
			}
		}
	}
	
	text = text.join(" ");
	return text;
	
	
	function censor(textWord, wordListWord)
	{
		newWord = "";
		
		for( p = 0; p < wordListWord.length; p++ )
		{
			for( q = 0; q < textWord.length; q++ )
			{
				if( wordListWord[p].toLowerCase() === textWord[q].toLowerCase() )
				{
					if( p == 0 )
					{
						newWord = newWord + textWord[q];
						break;
					}
					if( p == wordListWord.length-1 && q != 0 )
					{
						newWord = newWord + textWord[q];
						break;
					}
					else if( p != wordListWord.length-1 )
					{
						newWord = newWord + "$$";
						break;
					}
				}
			}
		}
	}
	
	function checkPalindrome(text)
	{
		var text = text;
		var text2 = "";
		var check = true;
		var i = 0;
		
		text = text.toLowerCase().replace(/[^a-z]+/g, "");
		
		for( i = text.length-1; i >= 0; i-- )
		{
			text2 = text2 + text[i];
		}
		
		
		for( i = 0; i < text.length; i++ )
		{
			if( !(text2[i] === text[i]) )
			{
				check = false;
				break;
			}
		}
		
		return check;
	}
}