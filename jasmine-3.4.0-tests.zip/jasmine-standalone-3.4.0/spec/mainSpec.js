describe("check task 1", function() 
{
	it("check: e, I have some cheese", function() 
	{
		expect( task1("e", "I have some cheese") ).toBe(5);
	});
	
	it("check: a, Walking on the pavement", function() 
	{
		expect( task1("a", "Walking on the pavement") ).toBe(2);
	});
});

describe("check task 2", function() 
{
	it("check: God saved Eva’s dog", function() 
	{
		expect( task2("God saved Eva’s dog") ).toBe(true);
	});
	
	it("check: I have some cheese", function() 
	{
		expect( task2("I have some cheese") ).toBe(false);
	});
	
	it("check: Was it a car or a cat I saw?", function() 
	{
		expect( task2("Was it a car or a cat I saw?") ).toBe(true);
	});
});

describe("check task 3a", function() 
{
	it("check: I have a cat named Meow and a dog name Woof. I love the dog a lot. He is larger than a small horse. with [dog, cat, large] ", function() 
	{
		expect( task3a("I have a cat named Meow and a dog name Woof. I love the dog a lot. He is larger than a small horse.", ["dog", "cat", "large"]) ).toEqual([2,1,1]);
	});
	
	it("check: Doggy dog dog went out for walk walk, then came back back here's he. with [dog, here]", function() 
	{
		expect( task3a("Doggy dog dog went out for walk walk, then came back back here's he.", ["dog", "here"]) ).toEqual([3,1]);
	});
});

describe("check task 3b", function() 
{
	it("check: I have a cat named Meow and a dog name Woof. I love the dog a lot. He is larger than a small horse.", function() 
	{
		expect( task3b("I have a cat named Meow and a dog name Woof. I love the dog a lot. He is larger than a small horse.", ["meow", "woof"]) ).toBe("I have a cat named M$$w and a dog name W$$f. I love the dog a lot. He is larger than a small horse.");
	});
	
	it("check: I have a cat named xMeowx and a dog name poofWoof. I love the dog a lot. He is larger than a small horse.", function() 
	{
		expect( task3b("I have a cat named xMeowx and a dog name poofWoof. I love the dog a lot. He is larger than a small horse.", ["meow", "woof"]) ).toBe("I have a cat named xM$$wx and a dog name poofW$$f. I love the dog a lot. He is larger than a small horse.");
	});
});

describe("check task 3c", function() 
{
	it("check: Anna went to vote in the election to fulfil her civic duty", function() 
	{
		expect( task3c("Anna went to vote in the election to fulfil her civic duty") ).toBe("A$$a went to vote in the election to fulfil her c$$$c duty");
	});
	
	it("check: pAnnap went to vote in the election to fulfil her ccivic duty", function() 
	{
		expect( task3c("pAnnap went to vote in the election to fulfil her ccivic duty") ).toBe("p$$$$p went to vote in the election to fulfil her ccivic duty");
	});
});